package application;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.control.PasswordField;

public class User_register_interfaceController {
	private Stage oldStage = null;
	@FXML
	private Button btn_register;
	@FXML
	private TextField tf_name;
	@FXML
	private PasswordField pstf_password1;
	@FXML
	private PasswordField pstf_password2;
	@FXML
	private TextField tf_college;
	@FXML
	private TextField tf_phnumber;
	@FXML
	private TextField tf_incode;
	@FXML
	private TextField tf_sex;
	@FXML
	private TextField tf_realname;
	
    
    @FXML
    void initialize() {
    	MySqlOp.connect();
    	if(tf_name.getText().equals("")) 
    	{
    		MySqlOp.closeConnection();
    		return;
    	}
		try {
			int flag=0;
			String sqlStr_administrators = "select * from administrators";
			String sqlStr_college = "select * from college";
			String sqlStr_invitation = "select * from invitation";
			//ѧԺ����Ա�����
	    	ResultSet rs1 = MySqlOp.getResultSet(sqlStr_administrators);
	    	//ѧԺ�����
	    	ResultSet rs2 = MySqlOp.getResultSet(sqlStr_college);
	    	//��֤������
	    	ResultSet rs3 = MySqlOp.getResultSet(sqlStr_invitation);
	    	ArrayList<CollegeAdministrators>List1 = new ArrayList<CollegeAdministrators>();
			while(rs1.next()) 
				List1.add(new CollegeAdministrators(rs1.getString(1),rs1.getString(2),rs1.getString(3),rs1.getString(4),rs1.getString(5),rs1.getString(6),rs1.getString(7)));
			ArrayList<College>List2 = new ArrayList<College>();
			while(rs2.next()) 
				List2.add(new College(rs2.getString(1),rs2.getString(2),rs2.getString(3)));
			ArrayList<Invitation>List3 = new ArrayList<Invitation>();
			while(rs3.next()) 
				List3.add(new Invitation(rs3.getString(1),rs3.getString(2)));
			//�ж��û����Ƿ����
			for(int i=0;i<List1.size();i++)
				if(tf_name.getText().equals(List1.get(i).getUser_name())) 
				{
					flag = 1;
					break;
				}
			if(flag==1) 
			{
				Alert alert = new Alert(Alert.AlertType.ERROR,"�û����Ѵ���");
				alert.show();
			}
			else 
			{
				//�ж�����ǰ���Ƿ���ͬ
				if(!pstf_password1.getText().equals(pstf_password2.getText()))
				{
					Alert alert = new Alert(Alert.AlertType.ERROR,"ǰ�����벻һ��");
					alert.show();
				}
				else 
				{
					flag=0;
					for(int i=0;i<List2.size();i++)
					{
						//System.out.println(tf_college.getText());
						if(tf_college.getText().equals(List2.get(i).getCollege_name())) 
						{
							flag=1;
							break;
						}
					}
					if(flag==0) 
					{
						Alert alert = new Alert(Alert.AlertType.ERROR,"����дѧԺ�����ڣ����顣");
						alert.show();
					}
					else 
					{
						//�жϵ绰�����Ƿ�Ϊ11λ
						if(tf_phnumber.getText().length()!=11) 
						{
							Alert alert = new Alert(Alert.AlertType.ERROR,"�������λ������ȷ��ʽ��Ϊ11λ");
							alert.show();
						}
						else 
						{
							flag=0;
							String POWER_CODE = "";
							//�ж���֤���Ƿ���ȷ
							for(int i=0;i<List3.size();i++) 
								if(tf_incode.getText().equals(List3.get(i).getInvitation_code())) 
								{
									flag=1;
									POWER_CODE=List3.get(i).getPower();
									break;
								}
							if(flag==0) 
							{
								Alert alert = new Alert(Alert.AlertType.ERROR,"��֤�����");
								alert.show();
							}
							else 
							{
								ResultSet rs = MySqlOp.getResultSet("select * from administrators");
								try {
									
									rs.moveToInsertRow();
									rs.updateString("����", tf_name.getText());
									rs.updateString("�Ա�", tf_sex.getText());
									rs.updateString("��ϵ��ʽ", tf_phnumber.getText());
									rs.updateString("�û���", tf_realname.getText());
									rs.updateString("��¼����", pstf_password1.getText());
									rs.updateString("Ȩ��", POWER_CODE);
									rs.updateString("ѧԺ", tf_college.getText());
									rs.insertRow();
									
									Stage stage = new Stage();
							    	Scene scene = new Scene(new User_login_interface(stage));
							    	scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
							    	stage.setScene(scene);
							    	stage.show();
							    	oldStage.hide();
								} catch (SQLException e1) {
									e1.printStackTrace();
								}
							}
						}
					}
				}
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		MySqlOp.closeConnection();
    }
    public void setOldStage(Stage stage) {
    	oldStage = stage;
    }
}
