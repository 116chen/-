package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import javafx.scene.control.PasswordField;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Change_passwordController {
	private Stage oldStage1 = null;
	private Stage oldStage2 = null;
	private String username;
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@FXML
	private PasswordField old_password;
	@FXML
	private PasswordField new_password_1;
	@FXML
	private PasswordField new_password_2;
	@FXML
	private Button btn_reset;
	@FXML
	private Button btn_save;
	
	@FXML
	public void password_Reset() 
	{
		System.out.println("��������");
		old_password.setText("");
		new_password_1.setText("");
		new_password_2.setText("");
	}
	
	@FXML
	public void password_Save() 
	{
		MySqlOp.connect();
		try {
			ResultSet rs = MySqlOp.getResultSet("select * from administrators");
			boolean flag = false;
			while(rs.next()) 
			{
				//�û��������붼��ͬ������²Ž����޸�
				if(username.equals(rs.getString(4))&&rs.getString(5).equals(old_password.getText())) 
				{
					flag = true;
					break;
				}
			}
			if(flag) 
			{
				if(new_password_1.getText().equals(new_password_2.getText()))
				{
					Connection con = MySqlOp.connect();
					PreparedStatement presta = con.prepareStatement("update administrators set ��¼����=? where �û���=?");
					presta.setString(1, new_password_1.getText());
					presta.setString(2, this.username);
					presta.execute();
					System.out.println("�޸ĳɹ��������ص�¼����");
					oldStage1.hide();
					oldStage2.hide();
					
					Stage stage = new Stage();
					Scene scene = new Scene(new User_login_interface(stage));
					scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
					stage.setScene(scene);
					stage.setTitle("��¼����");
					stage.initModality(Modality.APPLICATION_MODAL);  
					stage.show();	
				}
				else 
				{
					Alert alert = new Alert(Alert.AlertType.ERROR,"ǰ�����벻һ��");
					alert.show();
				}
			}
			else 
			{
				Alert alert = new Alert(Alert.AlertType.ERROR,"�������������������");
				alert.show();
			}
		}catch (SQLException e1) {
			e1.printStackTrace();
		}
		MySqlOp.closeConnection();
	}
	public void setOldStage1(Stage stage) {
    	oldStage1 = stage;
    }

	public void setOldStage2(Stage stage) {
		oldStage2 = stage;
	}
}
