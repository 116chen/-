package application;

public class Invitation {
	private String invitation_code;
	private String power;
	public String getInvitation_code() {
		return invitation_code;
	}
	public void setInvitation_code(String invitation_code) {
		this.invitation_code = invitation_code;
	}
	public String getPower() {
		return power;
	}
	public void setPower(String power) {
		this.power = power;
	}
	public Invitation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Invitation(String invitation_code, String power) {
		super();
		this.invitation_code = invitation_code;
		this.power = power;
	}
}
