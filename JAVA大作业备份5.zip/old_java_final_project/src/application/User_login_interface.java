package application;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class User_login_interface extends StackPane{

	public User_login_interface(Stage stage) { 
		try {
			FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("user_login_interface.fxml"));
			this.getChildren().add(fxmlloader.load());
			
			((User_login_interfaceController)fxmlloader.getController()).setOldStage(stage);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	



}
