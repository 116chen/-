package application;

public class Sport {
	final private int MAX = 9;
	
	private String sport_ID;
	private String sport_name;
	private int number;
	private int best_grade;
	private int get_sorce;
	public String getSport_ID() {
		return sport_ID;
	}
	public void setSport_ID(String sport_ID) {
		this.sport_ID = sport_ID;
	}
	public String getSport_name() {
		return sport_name;
	}
	public void setSport_name(String sport_name) {
		this.sport_name = sport_name;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public int getBest_grade() {
		return best_grade;
	}
	public void setBest_grade(int best_grade) {
		this.best_grade = best_grade;
	}
	public int getGet_sorce() {
		return get_sorce;
	}
	public void setGet_sorce(int get_sorce) {
		this.get_sorce = get_sorce;
	}
	public Sport(String sport_ID, String sport_name, int number, int best_grade, int get_sorce) {
		super();
		this.sport_ID = sport_ID;
		this.sport_name = sport_name;
		this.number = number;
		this.best_grade = best_grade;
		this.get_sorce = get_sorce;
	}
	public Sport() {
		super();
		this.sport_ID = "";
		this.sport_name = "";
		this.number = 0;
		this.best_grade = MAX;
		this.get_sorce = 0;
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Sport [sport_ID=" + sport_ID + ", sport_name=" + sport_name + ", number=" + number + ", best_grade="
				+ best_grade + ", get_sorce=" + get_sorce + "]";
	}
	
	
}
