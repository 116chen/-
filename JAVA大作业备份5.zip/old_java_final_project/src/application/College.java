package application;

public class College {
	private String college_name;
	private String college_sum_sorce;
	private String college_top_sorce;
	public String getCollege_name() {
		return college_name;
	}
	public void setCollege_name(String college_name) {
		this.college_name = college_name;
	}
	public String getCollege_sum_sorce() {
		return college_sum_sorce;
	}
	public void setCollege_sum_sorce(String college_sum_sorce) {
		this.college_sum_sorce = college_sum_sorce;
	}
	public String getCollege_top_sorce() {
		return college_top_sorce;
	}
	public void setCollege_top_sorce(String college_top_sorce) {
		this.college_top_sorce = college_top_sorce;
	}
	public College(String college_name, String college_sum_sorce, String college_top_sorce) {
		super();
		this.college_name = college_name;
		this.college_sum_sorce = college_sum_sorce;
		this.college_top_sorce = college_top_sorce;
	}
	public College() {
		super();
		// TODO Auto-generated constructor stub
	}
}
