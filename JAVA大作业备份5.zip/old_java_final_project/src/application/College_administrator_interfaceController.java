package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.TableView;

import javafx.scene.control.TableColumn;

public class College_administrator_interfaceController {
	private Stage oldStage = null;
	private ObservableList<Athlete_information> list;
	private ObservableList<Athlete_grade_serch> list_1;
	private ObservableList<Sport> list_2;
	private ObservableList<Rank> list_3;
	
	
	private ObservableList<Athlete_information> list_tmp;
	private ObservableList<Athlete_grade_serch> list_1_tmp;
	private ObservableList<Sport> list_2_tmp;
	@FXML
	private TextField tf_username;
	@FXML
	private TextField tf_realname;
	@FXML
	private TextField tf_sex;
	@FXML
	private TextField tf_college;
	@FXML
	private TextField tf_phone;
	@FXML
	private Button btn_changePw;
	@FXML
	private Button btn_save;
	@FXML
	private TextField tf_findID;
	@FXML
	private Button btn_findID;
	@FXML
	private TableView<Athlete_information> tv_athletes;
	@FXML
	private TableColumn<Athlete_information,String> tvc_ID;
	@FXML
	private TableColumn<Athlete_information,String> tvb_realname;
	@FXML
	private TableColumn<Athlete_information,String> tvb_sex;
	@FXML
	private TableColumn<Athlete_information,String> tvb_phone;
	@FXML
	private TableColumn<Athlete_information,String> tvb_sport_1;
	@FXML
	private TableColumn<Athlete_information,String> tvb_sport_2;
	@FXML
	private Button btn_add;
	@FXML
	private Button btn_change;
	@FXML
	private Button btn_delete;
	@FXML
	private TextField tf_findID_3;
	@FXML
	private Button btn_findID_3;
	@FXML
	private TableView<Athlete_grade_serch> tv_athletes1;
	@FXML
	private TableColumn<Athlete_grade_serch,String> tvc_ID_3;
	@FXML
	private TableColumn<Athlete_grade_serch,String> tvb_realname_3;
	@FXML
	private TableColumn<Athlete_grade_serch,String> tvb_sports_31;
	@FXML
	private TableColumn<Athlete_grade_serch,String> tvb_grade_31;
	@FXML
	private TableColumn<Athlete_grade_serch,String> tvb_sport_32;
	@FXML
	private TableColumn<Athlete_grade_serch,String> tvb_grade_32;
	@FXML
	private TextField tf_sportID_4;
	@FXML
	private Button btn_findsportID_4;
	@FXML
	private TableView<Sport> tv_athletes11;
	@FXML
	private TableColumn<Sport,String> tvc_sportID_4;
	@FXML
	private TableColumn<Sport,String> tvb_sportname_4;
	@FXML
	private TableColumn<Sport,Integer> tvb_numofstu_4;
	@FXML
	private TableColumn<Sport,Integer> tvb_bestGrade_4;
	@FXML
	private TableColumn<Sport,Integer> tvb_grade_4;
	@FXML
	private TableView<Rank> tv_rank;
	@FXML
	private TableColumn<Rank,Integer> tvb_socre_4;
	@FXML
	private TableColumn<Rank,Integer> tvb_rank_4;
	@FXML
	private Button btn_refresh_2;
	@FXML
	private Button btn_refresh_3;
	@FXML
	private Button btn_refresh_4;
	
	//���þ���̨
	public void setOldStage(Stage stage) {
    	oldStage = stage;
    }
	
	//������Ϣ�ĳ�ʼ��
	public void init(CollegeAdministrators tmp) 
	{
		this.tf_username.setText(tmp.getUser_name());
		this.tf_realname.setText(tmp.getName());
		this.tf_sex.setText(tmp.getSex());
		this.tf_college.setText(tmp.getCollege());
		this.tf_phone.setText(tmp.getContact());
	}
	
	//�޸���Ϣ������
	@FXML                
	public void Save() 
	{
		try {
			PreparedStatement presta = MySqlOp.connect().prepareStatement("update administrators set ����=?,�Ա�=?,��ϵ��ʽ=?, ѧԺ=?where �û���=?");
			presta.setString(1, tf_realname.getText());
			presta.setString(2, tf_sex.getText());
			presta.setString(3, tf_phone.getText());
			presta.setString(4, tf_college.getText());
			presta.setString(5, tf_username.getText());
			presta.execute();
			Alert alert = new Alert(Alert.AlertType.INFORMATION,"�޸ĳɹ�");
			alert.show();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		MySqlOp.closeConnection();
	}
	
	//�޸����� ���� �˳�����¼���� 
	@FXML
	public void change_password() 
	{
		Stage stage = new Stage();
		Scene scene = new Scene(new Change_password(oldStage,stage,tf_username.getText()));
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setTitle("�޸�����");
		stage.initModality(Modality.APPLICATION_MODAL);  
		stage.show();
	}
	
	//�����˶�Ա��Ϣ
	@FXML
    void add_athlete() {
    	Stage stage = new Stage();
    	Scene scene = new Scene(new Add_athlete_information(stage,true,list,tf_college.getText(),this.getTableViewIndex() ));
    	scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
    	stage.setScene(scene);
    	stage.setTitle("add athlete");
    	stage.initModality(Modality.APPLICATION_MODAL);  
    	stage.show();
    }
	
	//�޸��˶�Ա��Ϣ
    @FXML
    void change_athlete() {
    	if(this.getTableViewIndex()==-1) 
    	{
    		Alert alert = new Alert(Alert.AlertType.ERROR,"��ѡ�����޸�");
    		alert.initModality(Modality.APPLICATION_MODAL);
			alert.show();
			return;
    	}
    	Stage stage = new Stage();
    	Scene scene = new Scene(new Add_athlete_information(stage,false,list,tf_college.getText(),this.getTableViewIndex()));
    	scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
    	stage.setScene(scene);
    	stage.setTitle("add athlete");
    	stage.initModality(Modality.APPLICATION_MODAL);
    	stage.show();
    }
    
    //ɾ���˶�Ա����
    @FXML
    void delete_athlete() 
    {
    	int index = getTableViewIndex();
    	
    	//δѡ��TableView
    	if(index==-1) 
    	{
    		Alert alert = new Alert(Alert.AlertType.ERROR,"��ѡ����ɾ��");
    		alert.initModality(Modality.APPLICATION_MODAL);
			alert.show();
			return;
    	}
    	
    	//ͨ��remove����TableView
    	String current_index = list.get(index).getAthlete_ID();
    	list.remove(index);
    	try {
	         Connection con = MySqlOp.connect();
	         
	         //���ݿ�ɾ����估����
	         String sql = "delete from athletes where ѧ��=?";
	         PreparedStatement presta = con.prepareStatement(sql);
	         presta.setString(1,current_index);
	         presta.execute();
	         sql = "delete from connection where ѧ��=?";
	         presta = con.prepareStatement(sql);
	         presta.setString(1,current_index);
	         presta.execute();
         } catch (SQLException e) {
             e.printStackTrace();
         }
    	
    	//����TableView������ʾȫ���˶�Ա
    	this.createTableView();
    	tf_findID.setText("");
    	MySqlOp.closeConnection();
    }
    
    //�����˶�Ա��Ϣ
    @FXML
    void serch_athlete() 
    {
    	list_tmp = FXCollections.observableArrayList();
    	//ѧ��Ϊ������ʾȫ���˶�Ա��Ϣ
    	if(tf_findID.getText().equals("")) 
    	{
    		MySqlOp.connect();
    		this.createTableView();
    		MySqlOp.closeConnection();
    	}
    	else 
    	{
    		
    		//flag�����ж��Ƿ����������ѧ��
    		boolean flag=true;
    		MySqlOp.connect();
    		this.createTableView();
    		MySqlOp.closeConnection();
    		for(int i=0;i<list.size();i++)
    			if(list.get(i).getAthlete_ID().equals(tf_findID.getText()))
    			{
    				flag=false;
    				list_tmp.add(list.get(i));
    				break;
    			}
    		
    		//����ѧ�������TableView�����򵯳�����
    		if(flag) 
    		{
    			Alert alert = new Alert(Alert.AlertType.ERROR,"���ҵ�ѧ�Ų�����");
        		alert.initModality(Modality.APPLICATION_MODAL);
    			alert.show();
    		}
    		else 
    		{
    			list.clear();
    			for(int i=0;i<list_tmp.size();i++)
    				list.add(list_tmp.get(i));
    		}
    	}
    }
    
    @FXML
    void serch_athlete_1()
    {
    	list_1_tmp = FXCollections.observableArrayList();
    	//ѧ��Ϊ������ʾȫ���˶�Ա��Ϣ
    	if(tf_findID_3.getText().equals("")) 
    	{
    		MySqlOp.connect();
    		this.createTableView_1();
    		MySqlOp.closeConnection();
    	}
    	else 
    	{
    		//flag�����ж��Ƿ����������ѧ��
    		boolean flag=true;
    		MySqlOp.connect();
    		this.createTableView_1();
    		MySqlOp.closeConnection();
    		for(int i=0;i<list_1.size();i++)
    		{
    			System.out.println("ID:"+list_1.get(i).getAthlete_ID());
    			if(list_1.get(i).getAthlete_ID().equals(tf_findID_3.getText()))
    			{
    				flag=false;
    				list_1_tmp.add(list_1.get(i));
    				break;
    			}
    		}
    		
    		//����ѧ�������TableView�����򵯳�����
    		if(flag) 
    		{
    			Alert alert = new Alert(Alert.AlertType.ERROR,"���ҵ�ѧ�Ų�����");
        		alert.initModality(Modality.APPLICATION_MODAL);
    			alert.show();
    		}
    		else 
    		{
    			list_1.clear();
    			for(int i=0;i<list_1_tmp.size();i++)
    				list_1.add(list_1_tmp.get(i));
    		}
    	}
    }
    
    @FXML
    void serch_athlete_2()
    {
    	list_2_tmp = FXCollections.observableArrayList();
    	if(tf_sportID_4.getText().equals("")) 
    	{
    		MySqlOp.connect();
    		this.createTableView_2();
    		MySqlOp.closeConnection();
    	}
    	else 
    	{
    		//flag�����ж��Ƿ���������ı��
    		boolean flag=true;
    		MySqlOp.connect();
    		this.createTableView_2();
    		MySqlOp.closeConnection();
    		for(int i=0;i<list_2.size();i++)
    		{
    			if(list_2.get(i).getSport_ID().equals(tf_sportID_4.getText()))
    			{
    				flag=false;
    				list_2_tmp.add(list_2.get(i));
    				break;
    			}
    		}
    		
    		//���ڱ�������TableView�����򵯳�����
    		if(flag) 
    		{
    			Alert alert = new Alert(Alert.AlertType.ERROR,"���ҵı�Ų�����");
        		alert.initModality(Modality.APPLICATION_MODAL);
    			alert.show();
    		}
    		else 
    		{
    			list_2.clear();
    			for(int i=0;i<list_2_tmp.size();i++)
    				list_2.add(list_2_tmp.get(i));
    		}
    	}
    }
    
    //�˶�Ա��Ϣ����TableView
    public void createTableView() 
    {
    	list = FXCollections.observableArrayList();
    	try 
    	{
    		//HashMap��athletes��connection��������ϵ
    		HashMap<String,Athlete_information>mp = new HashMap<String,Athlete_information>();
    		
    		//����athletes��
        	ResultSet rs = MySqlOp.getResultSet("select * from athletes");
        	while(rs.next()) 
        	{
        		
        		if(rs.getString(5).equals(tf_college.getText())==false)continue;
        		Athlete_information tmp = new Athlete_information();
        		tmp.setAthlete_ID(rs.getString(4));
        		tmp.setName(rs.getString(1));
        		tmp.setSex(rs.getString(2));
        		tmp.setContact(rs.getString(3));
        		mp.put(rs.getString(4), tmp);
        	}
        	
        	//����connection��
        	ResultSet rs1 = MySqlOp.getResultSet("select * from connection");
        	while(rs1.next()) 
        	{
        		System.out.println("college:"+tf_college.getText());
        		if(rs1.getString(3).equals(tf_college.getText())==false)continue;
        		Athlete_information tmp = mp.get(rs1.getString(1));
        		tmp.setSport1(rs1.getString(4));
        		tmp.setSport2(rs1.getString(6));
        		mp.put(tmp.getAthlete_ID(), tmp);
        	}
        	
        	//����HashMap
        	for(String key:mp.keySet())
            {
        		mp.get(key).setCollege(tf_college.getText());
        		list.add(mp.get(key));
            }
        	
        	//���ݰ�
        	tvc_ID.setCellValueFactory(new PropertyValueFactory<Athlete_information, String>("athlete_ID"));
        	tvb_sex.setCellValueFactory(new PropertyValueFactory<Athlete_information, String>("sex"));
        	tvb_realname.setCellValueFactory(new PropertyValueFactory<Athlete_information, String>("name"));
        	tvb_phone.setCellValueFactory(new PropertyValueFactory<Athlete_information, String>("contact"));
        	tvb_sport_1.setCellValueFactory(new PropertyValueFactory<Athlete_information, String>("sport1"));
        	tvb_sport_2.setCellValueFactory(new PropertyValueFactory<Athlete_information, String>("sport2"));
        	tv_athletes.setItems(list);
    	}
    	catch (SQLException e1) {
			e1.printStackTrace();
		}
		MySqlOp.closeConnection();
    }
    
    public void createTableView_1() 
    {
    	list_1 = FXCollections.observableArrayList();
    	list_2 = FXCollections.observableArrayList();
    	try {
    		MySqlOp.connect();
    		ResultSet rs = MySqlOp.getResultSet("select * from connection");
        	while(rs.next()) 
        	{
        		if(rs.getString(3).equals(tf_college.getText())==false)continue;
        		Athlete_grade_serch tmp = new Athlete_grade_serch();
        		tmp.setAthlete_ID(rs.getString(1));
        		tmp.setName(rs.getString(2));
        		tmp.setSport1(rs.getString(4));
        		tmp.setGrade1(rs.getString(5));
        		tmp.setSport2(rs.getString(6));
        		tmp.setGrade2(rs.getString(7));
        		list_1.add(tmp);
        	}
        	tvc_ID_3.setCellValueFactory(new PropertyValueFactory<Athlete_grade_serch,String>("athlete_ID"));
        	tvb_realname_3.setCellValueFactory(new PropertyValueFactory<Athlete_grade_serch,String>("name"));
        	tvb_sports_31.setCellValueFactory(new PropertyValueFactory<Athlete_grade_serch,String>("sport1"));
        	tvb_sport_32.setCellValueFactory(new PropertyValueFactory<Athlete_grade_serch, String>("sport2"));
        	tvb_grade_31.setCellValueFactory(new PropertyValueFactory<Athlete_grade_serch, String>("grade1"));
        	tvb_grade_32.setCellValueFactory(new PropertyValueFactory<Athlete_grade_serch, String>("grade2"));
        	tv_athletes1.setItems(list_1);
    	}
    	catch (SQLException e1) {
			e1.printStackTrace();
		}
		MySqlOp.closeConnection();
    } 
    
    public void createTableView_2() 
    {
    	list_2 = FXCollections.observableArrayList();
    	list_3 = FXCollections.observableArrayList();
    	try {
    		HashMap<String,Sport>mp = new HashMap<String,Sport>();
    		MySqlOp.connect();
    		ResultSet rs = MySqlOp.getResultSet("select * from connection");
        	while(rs.next()) 
        	{
        		if(rs.getString(3).equals(tf_college.getText())==false)continue;
        		String tmp = rs.getString(8);
        		if(mp.containsKey(tmp)==false) 
        			mp.put(tmp, new Sport());
        		mp.get(tmp).setSport_ID(rs.getString(8));
        		mp.get(tmp).setSport_name(rs.getString(4));
        		mp.get(tmp).setNumber(mp.get(tmp).getNumber()+1);
        		int num_tmp = mp.get(tmp).getGet_sorce()+9-Integer.valueOf(rs.getString(5)).intValue();
        		if(num_tmp != 9)
        			mp.get(tmp).setGet_sorce(num_tmp);
        		if(mp.get(tmp).getBest_grade()>Integer.valueOf(rs.getString(5)).intValue())
        			mp.get(tmp).setBest_grade(Integer.valueOf(rs.getString(5)).intValue());
        		
        		tmp = rs.getString(9);
        		if(mp.containsKey(tmp)==false) 
        			mp.put(tmp, new Sport());
        		mp.get(tmp).setSport_ID(rs.getString(9));
        		mp.get(tmp).setSport_name(rs.getString(6));
        		mp.get(tmp).setNumber(mp.get(tmp).getNumber()+1);
        		num_tmp = mp.get(tmp).getGet_sorce()+9-Integer.valueOf(rs.getString(7)).intValue();
        		if(num_tmp != 9)
        			mp.get(tmp).setGet_sorce(num_tmp);
        		if(mp.get(tmp).getBest_grade()>Integer.valueOf(rs.getString(7)).intValue())
        			mp.get(tmp).setBest_grade(Integer.valueOf(rs.getString(7)).intValue());
        	}
        	for(String key:mp.keySet()) 
        		list_2.add(mp.get(key));
        	int sum = 0;
        	for(int i=0;i<list_2.size();i++)
        		sum+=list_2.get(i).getGet_sorce();
        	
        	tvc_sportID_4.setCellValueFactory(new PropertyValueFactory<Sport,String>("sport_ID"));
        	tvb_sportname_4.setCellValueFactory(new PropertyValueFactory<Sport,String>("sport_name"));
        	tvb_numofstu_4.setCellValueFactory(new PropertyValueFactory<Sport,Integer>("number"));
        	tvb_bestGrade_4.setCellValueFactory(new PropertyValueFactory<Sport, Integer>("best_grade"));
        	tvb_grade_4.setCellValueFactory(new PropertyValueFactory<Sport, Integer>("get_sorce"));
        	tv_athletes11.setItems(list_2);
        	
        
        	//�˴�1Ϊ��ʱ.....................
        	list_3.add(new Rank(1,sum));
        	tvb_rank_4.setCellValueFactory(new PropertyValueFactory<Rank, Integer>("rank"));
        	tvb_socre_4.setCellValueFactory(new PropertyValueFactory<Rank, Integer>("get_sorce"));
        	tv_rank.setItems(list_3);
    	}
    	catch (SQLException e1) {
			e1.printStackTrace();
		}
		MySqlOp.closeConnection();
    } 
    
    @FXML
    public void Refresh() 
    {
    	MySqlOp.connect();
    	System.out.println("sadsadas");
    	this.createTableView();
    	this.createTableView_1();
    	this.createTableView_2();
    	MySqlOp.closeConnection();
    }
    
    //�����������TableViewλ��
    public int getTableViewIndex() 
    {
    	return tv_athletes.getSelectionModel().getSelectedIndex();
    }
}
