package application;

public class Athlete_information {
	protected String athlete_ID;
	protected String name;
	protected String sex;
	protected String contact;
	protected String sport1;
	protected String sport2;
	protected String college;
	public String getAthlete_ID() {
		return athlete_ID;
	}
	public void setAthlete_ID(String athlete_ID) {
		this.athlete_ID = athlete_ID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getSport1() {
		return sport1;
	}
	public void setSport1(String sport1) {
		this.sport1 = sport1;
	}
	public String getSport2() {
		return sport2;
	}
	public void setSport2(String sport2) {
		this.sport2 = sport2;
	}
	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}
	public Athlete_information() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Athlete_information(String athlete_ID, String name, String sex, String contact, String sport1,
			String sport2 ,String college) {
		super();
		this.athlete_ID = athlete_ID;
		this.name = name;
		this.sex = sex;
		this.contact = contact;
		this.sport1 = sport1;
		this.sport2 = sport2;
		this.college = college;
	}
	
	
}
