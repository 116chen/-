package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.Label;

public class Add_athlete_informationController {
	
	private ObservableList<Athlete_information> list_tmp;
	
	private HashMap<String,String>mp = new HashMap<String,String>();
	
	//ѧԺ���Ե�����
	private String college;
	
	//�޸Ĳ����Ķ�λ
	private int index;
	
	private String tmp_ID;

	private boolean flag;

	private Stage oldStage = null;
	@FXML
	private Label lable_ta;
	@FXML
	private TextField tf_sno;
	@FXML
	private TextField tf_name;
	@FXML
	private TextField tf_sex;
	@FXML
	private TextField tf_phone;
	@FXML
	private TextField tf_sport_1;
	@FXML
	private TextField tf_sport_2;
	@FXML
	private Button btn_ALL;
	
	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}
	
	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}
	
	//list_tmp��get��set����
	public ObservableList<Athlete_information> getList_tmp() {
		return list_tmp;
	}
	
	public void setList_tmp(ObservableList<Athlete_information> list_tmp) {
		this.list_tmp = list_tmp;
	}
	
	public void init(ObservableList<Athlete_information> list_tmp,int index) 
	{
		Athlete_information tmp = list_tmp.get(index);
		tf_sno.setText(tmp.getAthlete_ID());
		tf_name.setText(tmp.getName());
		tf_sex.setText(tmp.getSex());
		tf_phone.setText(tmp.getContact());
		tf_sport_1.setText(tmp.getSport1());
		tf_sport_2.setText(tmp.getSport2());
		this.tmp_ID = tmp.getAthlete_ID();
	}
	
	//���ӻ��޸İ�ť��ʾ
	@FXML
	public void setBtnText(boolean flag) {
		this.flag = flag;
		if(this.flag) {
			btn_ALL.setText("����");
			lable_ta.setText("�����˶�Ա��Ϣ");
		}
		else {
			btn_ALL.setText("�޸�");
			lable_ta.setText("�޸��˶�Ա��Ϣ");
		}
	}
	
	public void ID_NAME() 
	{
		try {
			MySqlOp.connect();
			ResultSet rs = MySqlOp.getResultSet("select * from id_name");
			while(rs.next()) 
			{
				if(mp.containsKey(rs.getString(2))==false)
					mp.put(rs.getString(2), rs.getString(1));
			}
		} catch (SQLException e) {
	        e.printStackTrace();
	    }
		MySqlOp.closeConnection();
	}
	
	//���ӻ��޸Ĳ���
	@FXML
	public void Add_or_Change() 
	{
		ID_NAME();
		if(this.flag) 
		{
			list_tmp.add(new Athlete_information(tf_sno.getText(), tf_name.getText(), tf_sex.getText(), tf_phone.getText(), tf_sport_1.getText(),tf_sport_2.getText(),college));
			oldStage.hide();
			Alert alert = new Alert(Alert.AlertType.INFORMATION,"���ӳɹ�");
			alert.initModality(Modality.APPLICATION_MODAL);
			alert.show();
			try {
				Connection con = MySqlOp.connect();
				
				//athletes��������
				String sql = "insert into athletes(����,�Ա�,��ϵ��ʽ,ѧ��,����ѧԺ) values (?,?,?,?,?)";
				PreparedStatement presta = con.prepareStatement(sql);
	            presta.setString(1, tf_name.getText());
	            presta.setString(2, tf_sex.getText());
	            presta.setString(3, tf_phone.getText());
	            presta.setString(4, tf_sno.getText());
	            presta.setString(5, college);
	            presta.execute();
	            
	            //connection��������
	            sql = "insert into connection(ѧ��,����,ѧԺ,��������1,��������2,���±��1,���±��2) values (?,?,?,?,?,?,?)";
	            presta = con.prepareStatement(sql);
	            presta.setString(1, tf_sno.getText());
	            presta.setString(2, tf_name.getText());
	            presta.setString(3, college);
	            presta.setString(4, tf_sport_1.getText());
	            presta.setString(5, tf_sport_2.getText());
	            presta.setString(6, mp.get(tf_sport_1.getText()));
	            presta.setString(7, mp.get(tf_sport_2.getText()));
	            presta.execute();
			} catch (SQLException e) {
		        e.printStackTrace();
		    }
			MySqlOp.closeConnection();
		}
		else 
		{
			System.out.println("index:"+index);
			list_tmp.remove(index);
			list_tmp.add(new Athlete_information(tf_sno.getText(), tf_name.getText(), tf_sex.getText(), tf_phone.getText(), tf_sport_1.getText(),tf_sport_2.getText(),college));
			try {
				//athletes�����޸�
				Connection con = MySqlOp.connect();
				String sql = "delete from athletes where ѧ��="+this.tmp_ID;
	            PreparedStatement presta = con.prepareStatement(sql);
	            presta.execute();
				sql = "insert into athletes(����,�Ա�,��ϵ��ʽ,����ѧԺ,ѧ��)values (?,?,?,?,?)";
				presta = con.prepareStatement(sql);
	            presta.setString(1, tf_name.getText());
	            presta.setString(2, tf_sex.getText());
	            presta.setString(3, tf_phone.getText());
	            presta.setString(4, college);
	            presta.setString(5, tf_sno.getText());
	            presta.execute();
	            
	            //connection�����޸�
				sql = "delete from connection where ѧ��="+this.tmp_ID;
				presta = con.prepareStatement(sql);
				presta.execute();
				sql = "insert into connection(����,ѧԺ,��������1,��������2,ѧ��,���±��1,���±��2)values (?,?,?,?,?,?,?)";
				presta = con.prepareStatement(sql);
	            presta.setString(1, tf_name.getText());
	            presta.setString(2, college);
	            presta.setString(3, tf_sport_1.getText());
	            presta.setString(4, tf_sport_2.getText());
	            presta.setString(5, tf_sno.getText());
	            presta.setString(6, mp.get(tf_sport_1.getText()));
	            presta.setString(7, mp.get(tf_sport_2.getText()));
	            presta.execute();
			} catch (SQLException e) {
		        e.printStackTrace();
		    }
			MySqlOp.closeConnection();
			oldStage.hide();
		}
	}
	
	//���þ���̨
	public void setOldStage(Stage stage) {
    	oldStage = stage;
    }
}
