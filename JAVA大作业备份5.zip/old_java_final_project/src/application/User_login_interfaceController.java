package application;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;

import javafx.scene.control.ToggleGroup;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.RadioButton;

import javafx.scene.control.PasswordField;

public class User_login_interfaceController {
	private Stage oldStage = null;
	@FXML
	private TextField name;
	@FXML
	private PasswordField password;
	@FXML
	private RadioButton cb_xy;
	@FXML
	private ToggleGroup radiogroup;
	@FXML
	private RadioButton cb_xt;
	@FXML
	private Button btn_login;
	@FXML
	private Button btn_register;
	
	
	private CollegeAdministrators current_user;
	
	public CollegeAdministrators getCurrent_user() {
		return current_user;
	}

	public void setCurrent_user(CollegeAdministrators current_user) {
		this.current_user = current_user;
	}

	@FXML
	void Register() {
    	// �����µĴ���
    	Stage stage = new Stage();
    	Scene scene = new Scene(new User_register_interface(stage));
    	scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
    	stage.setScene(scene);
    	stage.setTitle("Register scene");
    	stage.show();
    	
    	// ����֮ǰ�Ĵ���
    	oldStage.hide();
    	
    }
	
	@FXML
	void Login() 
	{
		MySqlOp.connect();
		try {

			String sqlStr = "select * from administrators";
			ResultSet rs = MySqlOp.getResultSet(sqlStr);
			ArrayList<CollegeAdministrators>List1 = new ArrayList<CollegeAdministrators>();
			while(rs.next()) 
				List1.add(new CollegeAdministrators(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7)));
			int flag=0;
			boolean flag_name=false;
			for(int i=0;i<List1.size();i++)
			{
				//System.out.println("password:"+List1.get(i).getPassword());
				//System.out.println("user_name:"+List1.get(i).getUser_name());
				if(List1.get(i).getUser_name().equals(name.getText()))
					flag_name=true;
				if(List1.get(i).getUser_name().equals(name.getText())
						&&List1.get(i).getPassword().equals(password.getText()))
				{
					if(cb_xy.isSelected()&&List1.get(i).getPower().equals("Ժ��")) 
					{
						flag = 1;
						current_user = List1.get(i);
					}
					else if(cb_xt.isSelected()&&List1.get(i).getPower().equals("У��"))
					{
						flag = 2;
						current_user = List1.get(i);
					}
					break;
				}
				
			}
			if(flag_name) 
			{
				if(flag==1||flag==2) {
					
					Stage stage = new Stage();
			    	Scene scene = new Scene(new College_administrator_interface(stage,current_user));
			    	scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			    	stage.setScene(scene);
			    	
			    	stage.show();
			    	if(flag==1) 
			    	{
			    		stage.setTitle("Ժ������Ա����");
			    		System.out.println("Ժ��");
			    	}
			    	else if(flag==2) 
			    	{
			    		stage.setTitle("У������Ա����");
			    		System.out.println("У��");
			    	}
			    	// ����֮ǰ�Ĵ���
			    	oldStage.hide();
				}
				else 
				{
					Alert alert = new Alert(Alert.AlertType.ERROR,"�������");
		    		alert.initModality(Modality.APPLICATION_MODAL);
					alert.show();
				}
			}
			else 
			{
				Alert alert = new Alert(Alert.AlertType.ERROR,"�û���������");
	    		alert.initModality(Modality.APPLICATION_MODAL);
				alert.show();
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		MySqlOp.closeConnection();
	}
    
    public void setOldStage(Stage stage) {
    	oldStage = stage;
    }
}
