package application;

public class Rank {
	private int rank;
	private int get_sorce;
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public int getGet_sorce() {
		return get_sorce;
	}
	public void setGet_sorce(int get_sorce) {
		this.get_sorce = get_sorce;
	}
	public Rank() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Rank(int rank, int get_sorce) {
		super();
		this.rank = rank;
		this.get_sorce = get_sorce;
	}
	
}
