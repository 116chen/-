package application;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class User_register_interface extends StackPane{

	public User_register_interface(Stage stage) {
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("user_register_interface.fxml")); 
			this.getChildren().add(fxmlLoader.load());
			((User_register_interfaceController)fxmlLoader.getController()).setOldStage(stage);

			//((User_register_interfaceController)fxmlloader.getController()).setOldStage(stage);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
