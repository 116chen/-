package application;

public class CollegeAdministrators {

	private String name;
	private String sex;
	private String contact;
	private String user_name;
	private String password;
	private String power;
	private String college;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPower() {
		return power;
	}
	public void setPower(String power) {
		this.power = power;
	}
	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}
	public CollegeAdministrators(String name, String sex, String contact, String user_name, String password,
			String power, String college) {
		super();
		this.name = name;
		this.sex = sex;
		this.contact = contact;
		this.user_name = user_name;
		this.password = password;
		this.power = power;
		this.college = college;
	}
	public CollegeAdministrators() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
