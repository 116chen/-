package application;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
public class College_administrator_interface extends StackPane{

	public College_administrator_interface(Stage stage,CollegeAdministrators current_user) { 
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("college_administrator_interface.fxml")); 
			
			this.getChildren().add(fxmlLoader.load());
			
			//��ȡcollege_administrator_interfaceController��Controller
			College_administrator_interfaceController controller = fxmlLoader.getController();
			
			//��ʼ��college_administrator_interfaceController����
			controller.init(current_user);
			
			controller.setOldStage(stage);
			controller.createTableView();
			
			controller.createTableView_1();
			
			controller.createTableView_2();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
