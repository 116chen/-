package application;

public class Connection {
	private String ID;
	private String name;
	private String college;
	private String sport1;
	private String sorce1;
	private String sport2;
	private String sorce2;
	private String sport_ID;
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}
	public String getSport1() {
		return sport1;
	}
	public void setSport1(String sport1) {
		this.sport1 = sport1;
	}
	public String getSorce1() {
		return sorce1;
	}
	public void setSorce1(String sorce1) {
		this.sorce1 = sorce1;
	}
	public String getSport2() {
		return sport2;
	}
	public void setSport2(String sport2) {
		this.sport2 = sport2;
	}
	public String getSorce2() {
		return sorce2;
	}
	public void setSorce2(String sorce2) {
		this.sorce2 = sorce2;
	}
	public String getSport_ID() {
		return sport_ID;
	}
	public void setSport_ID(String sport_ID) {
		this.sport_ID = sport_ID;
	}
	public Connection() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Connection(String iD, String name, String college, String sport1, String sorce1, String sport2,
			String sorce2, String sport_ID) {
		super();
		ID = iD;
		this.name = name;
		this.college = college;
		this.sport1 = sport1;
		this.sorce1 = sorce1;
		this.sport2 = sport2;
		this.sorce2 = sorce2;
		this.sport_ID = sport_ID;
	}
	
}
