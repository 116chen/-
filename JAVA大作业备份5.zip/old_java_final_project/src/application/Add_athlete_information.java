package application;

import java.io.IOException;

import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.layout.StackPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Add_athlete_information extends StackPane{
	//stage����̨		flag�޸Ļ�������	list_tmp���ô���
	public Add_athlete_information(Stage stage,boolean flag,ObservableList<Athlete_information> list_tmp,String college,int index) { 
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("add_athlete_information.fxml")); 
			this.getChildren().add(fxmlLoader.load());
			Add_athlete_informationController controller = fxmlLoader.getController();
			controller.setList_tmp(list_tmp);
			controller.setCollege(college);
			controller.setBtnText(flag);
			controller.setIndex(index);
			if(flag==false) 
				controller.init(list_tmp,index);
			controller.setOldStage(stage);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
