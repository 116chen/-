package application;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
public class Change_password extends StackPane{
	public Change_password(Stage oldStage,Stage stage,String username) { 
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("change_password.fxml")); 
			this.getChildren().add(fxmlLoader.load());
			Change_passwordController controller = fxmlLoader.getController();
			controller.setUsername(username);
			controller.setOldStage1(oldStage);
			controller.setOldStage2(stage);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
