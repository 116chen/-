package application;

public class Athlete_grade_serch extends Athlete_information{
	private String grade1;
	private String grade2;
	public String getGrade1() {
		return grade1;
	}
	public void setGrade1(String grade1) {
		this.grade1 = grade1;
	}
	public String getGrade2() {
		return grade2;
	}
	public void setGrade2(String grade2) {
		this.grade2 = grade2;
	}
	public Athlete_grade_serch() {
		super();
	}
	public Athlete_grade_serch(String athlete_ID, String name, String sex, String contact, String sport1, String sport2,
			String college,String grade1, String grade2) {
		super(athlete_ID, name, sex, contact, sport1, sport2, college);
		this.grade1 = grade1;
		this.grade2 = grade2;
	}
}
