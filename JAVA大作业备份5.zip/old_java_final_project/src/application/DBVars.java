package application;
public class DBVars {
	static final String DRIVER_NAME = "com.mysql.jdbc.Driver";
	static final String URL = "jdbc:mysql://127.0.0.1:3306/userinformation?useUnicode=true&characterEncoding=UTF-8";
	static final String USER = "root";
	static final String PASSWORD = "";
}